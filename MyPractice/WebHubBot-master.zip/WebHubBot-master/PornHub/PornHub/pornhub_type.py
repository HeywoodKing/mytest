#coding:utf-8
"""归纳PornHub资源链接"""
PH_TYPES = [
    '',
    'recommended',
    'video?o=ht', # hot
    'video?o=mv', # Most Viewed
    'video?o=tr' #Top Rate
]